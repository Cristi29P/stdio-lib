/* @Copyright Paris Cristian-Tanase / Operating Systems 2022 */
#include "so_stdio.h"
#include "useful.h"
#define DLL_EXPORTS

struct _so_file
{
	PROCESS_INFORMATION pi;         /* Process info */
	HANDLE fd;                      /* The associated file handle */
	int file_pointer;               /* Cursor position inside file */
	int buffer_pointer;             /* Cursor position inside buffer */
	int last_bytes;                 /* Bytes added to buffer */
	int last_action;                /* Last I/O operation on the buffer */
	int error;                      /* Flag set if error occurred */
	int eof_reached;
	char opening_mode[MODE_LENGTH];
	char buffer[BUFF_SIZE];         /* The associated file buffer */
};

SO_FILE *so_fopen(const char *pathname, const char *mode)
{
	SO_FILE *f = NULL;
	int flags;
	HANDLE fd;

	flags = get_flags(mode);
	if (flags == INVALID_FLAGS)
		return NULL;

	fd = CreateFile(pathname, GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		NULL, flags, FILE_ATTRIBUTE_NORMAL, NULL);

	if (fd == INVALID_HANDLE_VALUE)
		return NULL;

	f = calloc(1, sizeof(SO_FILE));
	if (!f)
		return NULL;

	/* Default file opening mode has no process attached */
	f->pi.hProcess = INVALID_HANDLE_VALUE;
	f->pi.hThread = INVALID_HANDLE_VALUE;
	f->fd = fd;
	strcpy_s(f->opening_mode, MODE_LENGTH, mode);

	return f;
}

int so_fclose(SO_FILE *stream)
{
	int rt = 0;
	/* The buffer needs to be flushed if last I/O task was to write */
	if (stream->last_action == WRITE_OPERATION) {
		if (so_fflush(stream)) {
			stream->error = 1;
			CloseHandle(stream->fd);
			free(stream);
			return SO_EOF;
		}
	}

	rt = CloseHandle(stream->fd);

	free(stream);
	return !rt;
}

HANDLE so_fileno(SO_FILE *stream)
{
	return stream->fd;
}

int so_fflush(SO_FILE *stream)
{
	int ret = 0, bytes_actually = 0;

	if (stream->last_action == WRITE_OPERATION) {
		int bytes_written = 0;
		/* Write the entire buffer to the file */
		/* Loop implementation taken from lab 2 */
		/* solutions (xwrite function) */
		while (bytes_written < stream->buffer_pointer) {
			ret = WriteFile(stream->fd,
			stream->buffer + bytes_written,
			stream->buffer_pointer - bytes_written,
			&bytes_actually, NULL);

			if (!ret) {
				stream->error = 1;
				return SO_EOF;
			}

			bytes_written += bytes_actually;
		}

		memset(stream->buffer, '\0', BUFF_SIZE);
		stream->last_bytes = 0;
		stream->buffer_pointer = 0;
		return 0;
	}

	return SO_EOF;
}

int so_fseek(SO_FILE *stream, long offset, int whence)
{
	DWORD ret;
	/* Invalidate the buffer if the last I/O task was read */
	if (stream->last_action == READ_OPERATION) {
		memset(stream->buffer, '\0', BUFF_SIZE);
		stream->buffer_pointer = 0;
		stream->last_bytes = 0;
	}
	/* Flush the buffer if the last I/O task was write */
	if (stream->last_action == WRITE_OPERATION) {
		if (so_fflush(stream)) {
			stream->error = 1;
			return SO_EOF;
		}
	}

	ret = SetFilePointer(stream->fd, offset, NULL, (DWORD)whence);

	if (ret == INVALID_SET_FILE_POINTER)
		return SO_EOF;

	stream->file_pointer = ret; /* Set new file pointer location */

	return 0;
}

long so_ftell(SO_FILE *stream)
{
	return stream->file_pointer;
}

size_t so_fread(void *ptr, size_t size, size_t nmemb, SO_FILE *stream)
{
	int bytes_read = 0;

	while (bytes_read < (int) (size * nmemb)) {
		char ch = (char) so_fgetc(stream);

		if (so_feof(stream) || so_ferror(stream))
			break;

		((char *) ptr)[bytes_read++] = ch;
	}
	return (bytes_read / size);
}

size_t so_fwrite(const void *ptr, size_t size, size_t nmemb, SO_FILE *stream)
{
	int bytes_written = 0;

	while (bytes_written < (int) (size * nmemb)) {
		so_fputc((int) ((char *) ptr)[bytes_written++], stream);
		if (so_ferror(stream))
			break;
	}
	return (bytes_written / size);
}

int so_fgetc(SO_FILE *stream)
{
	int numberOfBytesRead, rv;
	unsigned char character;
	/* We check if the file is opened under read mode */
	if (readRight(stream->opening_mode)) {
		if (stream->buffer_pointer == stream->last_bytes) {
			/* Make sure the buffer is clean */
			memset(stream->buffer, '\0', BUFF_SIZE);
			rv = ReadFile(stream->fd, stream->buffer,
			BUFF_SIZE, &numberOfBytesRead, NULL);

			if (rv && !numberOfBytesRead) {
				stream->eof_reached = !stream->eof_reached;
				return SO_EOF;
			}

			if (rv == 0) {
				stream->error = 1;
				return SO_EOF;
			}

			stream->last_bytes = numberOfBytesRead;
			/* Make sure we read from the beginning of the buffer */
			stream->buffer_pointer = 0;
		}
		stream->file_pointer++;
		stream->last_action = READ_OPERATION;
		character = stream->buffer[stream->buffer_pointer++];
		return (int) character;
	}
	/* We couldn't read a character, so we have an error */
	stream->error = 1;
	return SO_EOF;
}

int so_fputc(int c, SO_FILE *stream)
{
	DWORD pos;

	if (writeRight(stream->opening_mode)) {
		if (!strncmp(stream->opening_mode, "a", 1)) {
			pos = SetFilePointer(stream->fd, 0,
				NULL, (DWORD)SEEK_END);
			if (pos == INVALID_SET_FILE_POINTER) {
				stream->error = 1;
				return SO_EOF;
			}
		}

		if (stream->buffer_pointer == BUFF_SIZE) {
			if (so_fflush(stream) == SO_EOF) {
				stream->error = 1;
				return SO_EOF;
			}
		}

		stream->buffer[stream->buffer_pointer++] = (char) c;
		stream->file_pointer++;
		stream->last_action = WRITE_OPERATION;
		return c;
	}
	/* We couldn't write a character, so we have an error */
	stream->error = 1;
	return SO_EOF;
}

int so_feof(SO_FILE *stream)
{
	return stream->eof_reached;
}

int so_ferror(SO_FILE *stream)
{
	return stream->error;
}

SO_FILE *custom_file(PROCESS_INFORMATION pi,
HANDLE file_descriptor, const char *mode)
{
	SO_FILE *f = NULL;

	if (get_flags(mode) == INVALID_FLAGS)
		return NULL;

	f = calloc(1, sizeof(SO_FILE));
	if (!f)
		return NULL;

	f->pi = pi;
	/* Default file opening mode has no process attached */
	f->pi.hProcess = INVALID_HANDLE_VALUE;
	f->pi.hThread = INVALID_HANDLE_VALUE;
	f->fd = file_descriptor;
	strcpy_s(f->opening_mode, MODE_LENGTH, mode);

	return f;
}

SO_FILE *so_popen(const char *command, const char *type)
{
	return NULL;
}

int so_pclose(SO_FILE *stream)
{
	return 0;
}
